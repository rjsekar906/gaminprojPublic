<?php
$con = mysqli_connect("localhost","root","","db_gaming");

// Check connection
if (mysqli_connect_errno())
  {
  	echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }else{

  	// Perform queries 
	$selectrows = mysqli_query($con,"SELECT * FROM tbl_deposit");
	// Fetch one and one row
	$datatArr = array();
	$returndata = array();
	while ($row=mysqli_fetch_row($selectrows))
    {
    	$rowArray = array();
    	for($i=1; $i<count($row); $i++){
    		array_push($rowArray,$row[$i]);
    	}
    	
    	array_push($datatArr,$rowArray);
    }
    $returndata['data']=$datatArr;
    header('Content-type: application/json');
    echo json_encode($returndata);
  }
